OS X Realtek Wifi Icons
==

This makes the icons in the Realtek StatusBarApp distributed by wifi dongle manufacturers such as TP-Link and Edimax fit in with OS X.

**Before:**

![](https://i.imgur.com/9O8CaTy.png)

**After:**

![](https://i.imgur.com/5OEbEb6.png)

To use, copy the contents of `icons/` into `/Library/Application Support/WLAN/StatusBarApp.app/Contents/Resources` and replace the existing files.
Then, log off and log back in.